<?php

namespace OXI_IMAGE_HOVER_UPLOADS\Square\Admin;

/**
 * Description of Effects1
 *
 * @author biplo
 */
use OXI_IMAGE_HOVER_UPLOADS\Square\Modules as Modules;

class Effects1 extends Modules {

    public function register_effects() {
        
    }

}
