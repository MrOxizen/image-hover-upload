<?php

namespace OXI_IMAGE_HOVER_UPLOADS\General\Admin;

/**
 * Description of Effects1
 *
 * @author biplo
 */
use OXI_IMAGE_HOVER_UPLOADS\General\Modules as Modules;
class Effects31 extends Modules {


}
